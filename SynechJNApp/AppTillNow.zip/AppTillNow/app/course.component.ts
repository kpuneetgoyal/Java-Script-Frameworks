
import {Component,Input} from '@angular/core'


@Component({
selector:`course`,
template:`<h1> {{coursedetails.name}}  </h1>
                <b>Price : {{coursedetails.price}} </b>
`
})
export class CourseComponent{
     @Input()   coursedetails={name:"Angular",price:3000};
}