// prefer default export if available
const preferDefault = m => m && m.default || m


exports.layouts = {
  "layout---index": preferDefault(require("F:/Trainings/MindTree_React_Apri_18/GatsbyJSExample/FirstGatsbyApp/.cache/layouts/index.js"))
}

exports.components = {
  "component---cache-dev-404-page-js": preferDefault(require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\dev-404-page.js")),
  "component---src-pages-404-js": preferDefault(require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\src\\pages\\404.js")),
  "component---src-pages-index-js": preferDefault(require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\src\\pages\\index.js")),
  "component---src-pages-page-2-js": preferDefault(require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\src\\pages\\page-2.js")),
  "component---src-pages-page-3-js": preferDefault(require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\src\\pages\\page-3.js"))
}

exports.json = {
  "layout-index.json": require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\layout-index.json"),
  "dev-404-page.json": require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\dev-404-page.json"),
  "404.json": require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\404.json"),
  "index.json": require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\index.json"),
  "page-2.json": require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\page-2.json"),
  "404-html.json": require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\404-html.json"),
  "page-3.json": require("F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\page-3.json")
}