
  import React from "react"
  import Component from "F:/Trainings/MindTree_React_Apri_18/GatsbyJSExample/FirstGatsbyApp/src/layouts/index.js"
  import data from "F:\\Trainings\\MindTree_React_Apri_18\\GatsbyJSExample\\FirstGatsbyApp\\.cache\\json\\layout-index.json"

  export default (props) => <Component {...props} {...data} />
  