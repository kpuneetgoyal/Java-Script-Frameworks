module.exports = {
  siteMetadata: {
    title: 'My First Gatsby App ',
  },
  plugins: ['gatsby-plugin-react-helmet'],
}
