var express = require('express');
var graphqlHttp = require('express-graphql')
var {buildSchema} = require('graphql');


var app = express();

// app.get('/',function(req,res){
//     res.send('Hello Node !');
// });
/* basic GraphQL Query  to return Hello GraphQL string ! */
/*
var schema =  buildSchema(`
    type Query{
        hello: String
    }
`);

var root = {
    hello :()=>{
        return 'Hello GraphQL !';
    }
} */

/* Schema for Posts */

var schema = buildSchema(`

type Query{
    Post(id:Int!):Post
    Posts:[Post]
}

type Post{
    id:Int!
    title:String
    body:String
    userId:Int
}
`);

var root = {
    Post:({id})=>{
            // return the actual data !
            return posts.find(p=> p.id == id);
    },
    Posts:()=>{
        return posts;
    }
}


/* Posts Data */

var posts = [
    {
      "userId": 1,
      "id": 1,
      "title": "sunt aut facere repellat provident occaecati excepturi optio reprehenderit",
      "body": "quia et suscipit\nsuscipit recusandae consequuntur expedita et cum\nreprehenderit molestiae ut ut quas totam\nnostrum rerum est autem sunt rem eveniet architecto"
    },
    {
      "userId": 1,
      "id": 2,
      "title": "qui est esse",
      "body": "est rerum tempore vitae\nsequi sint nihil reprehenderit dolor beatae ea dolores neque\nfugiat blanditiis voluptate porro vel nihil molestiae ut reiciendis\nqui aperiam non debitis possimus qui neque nisi nulla"
    },
    {
      "userId": 1,
      "id": 3,
      "title": "ea molestias quasi exercitationem repellat qui ipsa sit aut",
      "body": "et iusto sed quo iure\nvoluptatem occaecati omnis eligendi aut ad\nvoluptatem doloribus vel accusantium quis pariatur\nmolestiae porro eius odio et labore et velit aut"
    },
    {
      "userId": 1,
      "id": 4,
      "title": "eum et est occaecati",
      "body": "ullam et saepe reiciendis voluptatem adipisci\nsit amet autem assumenda provident rerum culpa\nquis hic commodi nesciunt rem tenetur doloremque ipsam iure\nquis sunt voluptatem rerum illo velit"
    },
    {
      "userId": 1,
      "id": 5,
      "title": "nesciunt quas odio",
      "body": "repudiandae veniam quaerat sunt sed\nalias aut fugiat sit autem sed est\nvoluptatem omnis possimus esse voluptatibus quis\nest aut tenetur dolor neque"
    }]

app.use('/graphql',graphqlHttp({

    schema:schema,
    rootValue:root,
    graphiql:true

}));
app.listen(6600,function(){
    console.log('Running a GraphQL API server at localhost:6600')
});


