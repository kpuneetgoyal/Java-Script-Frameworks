
import React from 'react';


export class HeaderComponent extends React.Component{
    render(){
        return <section>
               <h1 className="Header"> Element Using JSX ! </h1>
               <p> Paragraph ! </p> 
          </section>
    }
}