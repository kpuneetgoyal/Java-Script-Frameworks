import React from 'react';
import ReactDOM from 'react-dom';

import ButtonComponent from './button.component';

export default class ButtonList extends React.Component{
    constructor(props){
        super(props);
        this.state = {list:[10,20,40,50,60]};
    }

    AddItem(){
        // 1. read the value from textbox !
        //2. create a new state ! (add the item to the collection)
        // 3. set the new state !

        var txtValue = ReactDOM.findDOMNode(this.refs.inputValue).value;

        var newState = [...this.state.list, 
            +(txtValue)];// ES 6 Spread Operator !

        this.setState({list:newState});
    }
    render(){
        var buttonsTobeCreated = this.state.list.map(
            (b,index)=>{
                return <ButtonComponent 
                initialcount={b} key={index} />
            }
        );
        return <div>
            <input type="text"
            ref="inputValue"
            className="form-control" />
            <input type="button" value="Add"
             className="btn btn-success"
             onClick={this.AddItem.bind(this)}
             /> <br/>
            {buttonsTobeCreated}
            </div>
    }

}