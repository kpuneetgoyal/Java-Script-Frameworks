import React from 'react';
import ReactDOM from 'react-dom';


export default class PostsComponent extends React.Component{

    constructor(props){
        super(props);
        this.state = {posts:[]};

    }

    componentDidMount(){
        // make ajax request !
        $.get('https://jsonplaceholder.typicode.com/posts',(response)=>{
           // ???
           this.setState({posts:response});
        })
    }
    render(){
        var postsToBeCreated = this.state.posts.map(
            p =>{
                return <li key={p.id}>{p.title}</li>
            }
        );
        return <div>
            <h1> All Posts </h1>      
            <ul>
                {postsToBeCreated}
                </ul>      
            </div>
    }

}