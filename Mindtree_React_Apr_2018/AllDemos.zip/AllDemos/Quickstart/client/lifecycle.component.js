import React from 'react';
import ReactDOM from 'react-dom';

export default class LifeCycleComponent extends React.Component{
    
    constructor(props){
        super(props);
        console.log('Within Constructor !');       
    }

    componentWillMount(){
        this.state = {companyname:'IBM'};
        console.log('Within componentWillMount !'); 
    }

    onChangeEventHandler(e){
            // console.log(e.target.value);
            /// set State
            this.setState({companyname:e.target.value})
    }

    componentDidMount(){
        // AJAX , use other framework, set timers, DOM Modification
        console.log('Within componentDidMount !')
    }

    shouldComponentUpdate(){
            console.log('Within shouldComponentUpdate !');
           if(arguments[1].companyname.length > 5){
               console.log(arguments[1].companyname);
               return false;
           }
            return true;

    }

    componentWillUpdate(){
        console.log('Within componentWillUpdate !');

    }

    componentDidUpdate(){
        console.log('Within componentDidUpdate !');

    }

    componentWillUnmount(){
        // called before the componet is removed from the dom !
            console.log('Before Component is deleted !');
    }

    DeleteComponentHandler(){
        ReactDOM.unmountComponentAtNode(
            document.getElementById('content')
        )
    }



    render(){
        console.log('Within Render !');
         return  <div>
                  Company :   <input type="text"  onChange={this.onChangeEventHandler.bind(this)} value={this.state.companyname} />
                  <b>{this.state.companyname}</b>

                  <br/>
                  <input type="button" value="Delete"
                   className="btn btn-danger"
                   onClick={this.DeleteComponentHandler.bind(this)}
                   />
             </div>
        }
}