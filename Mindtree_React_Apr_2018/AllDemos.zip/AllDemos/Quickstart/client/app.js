// Code Here    
import React from 'react';
import ReactDOM from 'react-dom';

import {HeaderComponent} from './HeaderComponent';

import {ShoppingCartComponent} from './shoppingcart.component';

import ButtonComponent from './button.component';
import ButtonList from './buttonlist.component';
import PostsComponent from './posts.component';
import LifeCycleComponent from './lifecycle.component';

ReactDOM.render(<LifeCycleComponent />,
    document.getElementById('content')); 

