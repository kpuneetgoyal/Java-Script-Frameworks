import React from 'react';


export default class ButtonComponent extends React.Component{
    
    constructor(props){
        super(props);
        this.state = {count:this.props.initialcount};
    }


    ClickHandler(){
      this.setState({count:this.state.count + 1})
    }
    
    render(){
         return   <button className="btn btn-primary"
         onClick={this.ClickHandler.bind(this)}
         >{this.state.count}</button>
        }
}