export function posts(defStore=[],action){
    switch(action.type){
        case 'INCREMENT_LIKES':       
        var index = action.index;
      
        return [
            ...defStore.slice(0,index),
            {...defStore[index],likes:defStore[index].likes+1},
            ...defStore.slice(index + 1)
        ]; 
        case 'FETCH_POSTS':        
                            defStore = action.response;
                         return  defStore;
            default:
            return defStore;            
    }

}