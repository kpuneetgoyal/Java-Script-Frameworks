import {posts} from './posts.reducers';
import {comments} from './comments.reducer';
import { combineReducers } from 'redux';



var rootReducer  = combineReducers({posts,comments});

export default rootReducer;