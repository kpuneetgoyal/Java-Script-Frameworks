export function comments(defStore=[],action){
    switch(action.type){
        case 'ADD_COMMENT':
            console.log('Within comments reducer !');
            console.log(defStore);
            return defStore;
            default:
            return defStore;            
    }
}