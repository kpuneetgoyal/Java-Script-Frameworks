// data !

import posts from './data/posts';
import comments from './data/comments';
import { createStore,applyMiddleware } from 'redux';
import ReduxThunk from 'redux-thunk';
import rootReducer from './reducers/rootReducer';

// Enhanced Object literal Syntax !
var defStore = {posts,comments};

// createStore(reducers,defaultStore)
var store = createStore(rootReducer,applyMiddleware(ReduxThunk));

export default store;