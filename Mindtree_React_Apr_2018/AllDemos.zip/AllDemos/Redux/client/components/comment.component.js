import React from 'react';
import ReactDOM from 'react-dom';

export default class CommentComponent extends React.Component{

    constructor(props){
            super(props);
    }

    render(){    
        return <div className="commentStyle">                
                        <b>{this.props.commentdetails.user}:</b> {this.props.commentdetails.text}
                    </div>
    }

}