import React from 'react';
import ReactDOM from 'react-dom';


import PostDetailComponent from './postdetails.component';
import CommentComponent from './comment.component';

export default class SinglePostComponent extends React.Component{

    constructor(props){
            super(props);
    }

    render(){
        


        // fetch the code from URL !

        var code = this.props.params.code;

        var index = this.props.myposts.findIndex(
            (p,i)=> p.code == code
        );

        var currPost = this.props.myposts[index];

        var commentsForPost = this.props.mycomments[code] || [];

        var commentsToBeCreated = commentsForPost.map(
            c=>{
                return <CommentComponent commentdetails={c} />
            }
        );

        return <div>
                    <PostDetailComponent
                    index={index}
                    {...this.props}
                    post={currPost}
                    />
                    {commentsToBeCreated}
            </div>
    }

}