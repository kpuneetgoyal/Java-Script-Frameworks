import React from 'react';
import ReactDOM from 'react-dom';
import PostDetailComponent from './postdetails.component'

export default class AllPostsComponent extends React.Component{

    constructor(props){
        super(props);        
    }

    render(){
        var postsToBeCreated = this.props.myposts.map(
            (p,i)=>{
             return   <PostDetailComponent
              post={p} {...this.props}
              key={p.id} 
              index={i}
              />
            }
        )   
        return <div>
            <h1> Posts </h1>
                    {postsToBeCreated}
            </div>
        
    }

}