import React from 'react';
import ReactDOM from 'react-dom';

export default class MainComponent extends React.Component{



    componentDidMount(){
        this.props.fetchPostsData();
    }

    render(){



        return <div>           
            {React.cloneElement(this.props.children,this.props)}
             </div>
    }

}