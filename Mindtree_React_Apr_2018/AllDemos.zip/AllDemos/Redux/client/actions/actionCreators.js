import axios from 'axios';

export function Increment(index){
    return {
        type:'INCREMENT_LIKES',
        index
    }
}

export function AddComment(){
    return {
        type:'ADD_COMMENT'
    }
}

export function fetchPostsData(){

    console.log('Within fetchPostsData');
    var aPromise = axios.get('https://api.myjson.com/bins/ecl7r');


   return (dispatch)=>{
       // make the action to be dispatched !
       aPromise.then(
           (response)=>{
            
            dispatch({type:'FETCH_POSTS',response:response.data});
            
           })
   }
}

