export function Increment(){
    return {
        type:'INCREMENT_LIKES'
    }
}

export function AddComment(){
    return {
        type:'ADD_COMMENT'
    }
}