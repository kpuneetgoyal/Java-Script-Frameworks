import React from 'react';
import ReactDOM from 'react-dom';

export default class SinglePostComponent extends React.Component{


    render(){
        return <h1> Single Post Component </h1>
    }

}