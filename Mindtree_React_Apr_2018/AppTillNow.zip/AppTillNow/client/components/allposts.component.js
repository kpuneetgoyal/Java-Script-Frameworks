import React from 'react';
import ReactDOM from 'react-dom';

export default class AllPostsComponent extends React.Component{


    render(){
        return <h1> All Posts Component </h1>
    }

}