import {connect} from 'react-redux';
import { bindActionCreators } from 'redux';
import * as allActions from '../actions/actionCreators';
import MainComponent from './main.component'


// store data exposed as props !
function mapStateToProps(storeData){
            return {
                myposts:storeData.posts,
                mycomments:storeData.comments
            }
}

// dispatcher binded with action creators !
function mapDispatchToProps(dispatch){
            return bindActionCreators(allActions,dispatch);
}

var app = connect(mapStateToProps,mapDispatchToProps)(MainComponent);
export default app;

