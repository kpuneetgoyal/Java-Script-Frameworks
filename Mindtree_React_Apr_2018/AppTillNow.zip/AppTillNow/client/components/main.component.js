import React from 'react';
import ReactDOM from 'react-dom';

export default class MainComponent extends React.Component{


    render(){

        console.log(this.props);

        return <div>           
            {React.cloneElement(this.props.children)}
             </div>
    }

}