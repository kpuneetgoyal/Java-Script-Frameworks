// data !

import posts from './data/posts';
import comments from './data/comments';
import { createStore } from 'redux';
import rootReducer from './reducers/rootReducer';

// Enhanced Object literal Syntax !
var defStore = {posts,comments};

// createStore(reducers,defaultStore)
var store = createStore(rootReducer,defStore);

export default store;