// Code Here
import React from 'react';
import ReactDOM from 'react-dom';
import {Provider} from 'react-redux';

import store from './store';

import {Router,Route,IndexRoute,browserHistory} from 'react-router';
import MainComponent from './components/main.component';
import AllPostsComponent from './components/allposts.component';
import SinglePostComponent from './components/singlepost.component';
import app from './components/mainscript';

var router = <Provider store={store}>
                        <Router history={browserHistory}>
                        <Route path="/" component={app} >
                            <IndexRoute component={AllPostsComponent}> 
                            </IndexRoute>
                            <Route path="/post" component={SinglePostComponent}>
                            </Route>
                        </Route>
                    </Router>
                    </Provider>

ReactDOM.render(router,document.getElementById('content'));