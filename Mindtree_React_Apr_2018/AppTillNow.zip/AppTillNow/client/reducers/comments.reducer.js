export function comments(defStore=[],action){
    switch(action.type){
        case 'ADD_COMMENT':
            console.log('Within comments reducer !');
            return defStore;
            default:
            return defStore;            
    }
}