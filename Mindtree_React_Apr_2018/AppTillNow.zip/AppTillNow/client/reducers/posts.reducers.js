export function posts(defStore=[],action){
    switch(action.type){
        case 'INCREMENT_LIKES':
            console.log('Within posts reducer !');
            return defStore;
            default:
            return defStore;            
    }

}